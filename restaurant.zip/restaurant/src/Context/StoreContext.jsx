import React, { useState, createContext, useEffect } from "react"
import { food_list } from "../assets/assets"

export const StoreContext = createContext(null)

const StoreContextProvider = (props) => {
  const [Cartitems, setCartItems] = useState({});

  const addToCart = (itemId) => {
    if (!Cartitems[itemId]) {
      setCartItems((prev) => ({ ...prev, [itemId]: 1 }))
    }
    else {
      setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] + 1 }))
    }
  }
  const removeFromCart = (itemId) => {
    setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] - 1 }))

  }
  const getTotalCartAmount = () => {
    let totalAmount = 0;
    for (const item in Cartitems) {
      if (Cartitems[item] > 0) {

        let itemInfo = food_list.find((product) => product._id === item)
        totalAmount += itemInfo.price * Cartitems[item];
      }
    }
    return totalAmount;
  }

  const contextValue = {
    food_list,
    Cartitems,
    setCartItems,
    addToCart,
    removeFromCart,
    getTotalCartAmount
  }
  return (
    <StoreContext.Provider value={contextValue}>
      {props.children}
    </StoreContext.Provider>
  )
}
export default StoreContextProvider