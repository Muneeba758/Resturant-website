import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
      <div className="header-contents">
        <h2> Order your favourite food here</h2>
        <p> Craving something delicious? Order your favorite food right here and enjoy fresh, tasty meals delivered straight to your door. Choose from a variety of dishes, from spicy snacks to sweet desserts, all made with love and quality ingredients. Simply place your order and satisfy your hunger in no time!</p>
        <button>View Menu</button>
      </div>
    </div>
  )
}

export default Header
