import React from 'react'
import './Exploremenu.css'
import {menu_list} from '../../assets/assets'
const Exploremenu = ({category,setCategory}) => {
  return (
    <div className='explore-menu'id='explore-menu'>
        <h1> Explore our menu</h1>
        <p className='explore-menu-text'> Craving something delicious? Order your favorite food right here and enjoy fresh, tasty meals delivered straight to your door. Choose from a variety of dishes, from spicy snacks to sweet desserts, all made with love and quality ingredients. Simply place your order and satisfy your hunger in no time!</p>
         <div className="explore-menu-list">
            {menu_list.map((item,index)=>{
                return(
                    <div onClick={()=> setCategory(prev=>prev===item.menu_name?"All":item.menu_name)} key={index} className='explore-menu-list-items'>
                     <img  className={category===item.menu_name?"active":""}src={item.menu_image} alt={item.menu_image} />
                     <p>{item.menu_name}</p>
                    </div>
                )
            })}
         </div>
         <hr/>
    </div>
  )
}

export default Exploremenu
